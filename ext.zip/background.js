// Placeholder for background logic (template storage, messaging)
chrome.runtime.onInstalled.addListener(() => {
  // Initialization logic here
});

chrome.action.onClicked.addListener((tab) => {
  // Step 1: Inject the MJML editor script URL as a global variable
  const mjmlEditorUrl = chrome.runtime.getURL('mjmlEditor.js');
  chrome.scripting.executeScript({
    target: {tabId: tab.id, frameIds: [0]},
    world: "MAIN",
    func: (scriptUrl) => {
      window.MJML_INJECT_URL = scriptUrl;
    },
    args: [mjmlEditorUrl]
  }).then(() => {
    // Step 2: Inject the actual MJML button logic
    chrome.scripting.executeScript({
      target: {tabId: tab.id, frameIds: [0]},
      world: "MAIN",
      files: ['inject-mjml.js']
    });
  });
});
