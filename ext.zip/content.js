// content.js
(function() {
  const editorUrl = chrome.runtime.getURL('mjmlEditor.js');

  // Set on the current frame's html tag
  document.documentElement.setAttribute('data-mjml-url', editorUrl);

  // Also try to set it on the top-level html tag if possible
  try {
    window.top.document.documentElement.setAttribute('data-mjml-url', editorUrl);
  } catch (e) {
    // This may fail due to Cross-Origin restrictions, which is fine
  }

  // Inject the main logic
  const runScript = document.createElement('script');
  runScript.src = chrome.runtime.getURL('inject-mjml.js');
  (document.head || document.documentElement).appendChild(runScript);
})();