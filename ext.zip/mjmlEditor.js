// mjmlEditor.js - Handles MJML Editor Modal UI
(function() {
  // 1. FORWARD DECLARE FUNCTIONS TO WINDOW IMMEDIATELY
  // This prevents the "is not a function" errors during load
  window.createMJMLModal = createMJMLModal;
  window.logAcceptanceCriteria = logAcceptanceCriteria;
  // Create modal HTML structure
  function createMJMLModal() {
    if (document.getElementById('mjml-editor-modal')) return;
    
    // Build the UI
    buildModalUI(); 

    console.log('[MJML] Initializing modal enhancements...');
    setTimeout(function() {
      // Check if functions exist before calling to be safe
      if (typeof window.setupMJMLLivePreview === 'function') window.setupMJMLLivePreview();
      if (typeof window.setupSaveButton === 'function') window.setupSaveButton();
      // ... call other setup functions ...
    }, 100);
  }

  function closeMJMLModal() {
    var modal = document.getElementById('mjml-editor-modal');
    if (modal) modal.remove();
  }

  // Template CRUD logic
  function getTemplates(callback) {
    chrome.storage.local.get(['templates'], function(result) {
      callback(result.templates || []);
    });
  }

  function saveTemplate(template, callback) {
    getTemplates(function(templates) {
      const now = new Date().toISOString();
      let existing = templates.find(t => t.name === template.name);
      if (existing) {
        existing.mjml = template.mjml;
        existing.lastEdited = now;
      } else {
        template.created = now;
        template.lastEdited = now;
        templates.push(template);
      }
      chrome.storage.local.set({ templates }, function() {
        callback && callback();
      });
    });
  }

  function deleteTemplate(name, callback) {
    getTemplates(function(templates) {
      templates = templates.filter(t => t.name !== name);
      chrome.storage.local.set({ templates }, function() {
        callback && callback();
      });
    });
  }

  // Expose CRUD to window for modal usage
  window.mjmlTemplateAPI = { getTemplates, saveTemplate, deleteTemplate };

  // MJML API conversion
  function convertMJMLWithAPI(mjml, callback) {
    fetch('https://api.mjml.io/v1/render', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // 'Authorization': 'Basic ' + btoa('YOUR_APP_ID:YOUR_SECRET_KEY') // Add credentials if needed
      },
      body: JSON.stringify({ mjml })
    })
    .then(res => res.json())
    .then(data => {
      if (data.html) {
        callback({ html: data.html, errors: data.errors || [] });
      } else {
        callback({ html: '', errors: [data.message || 'Conversion failed'] });
      }
    })
    .catch(err => {
      callback({ html: '', errors: [err.message] });
    });
  }
  window.convertMJMLWithAPI = convertMJMLWithAPI;

  // --- MJML Live Preview and Error Handling ---
  function setupMJMLLivePreview() {
    var editor = document.getElementById('mjml-code-editor');
    var preview = document.getElementById('mjml-preview-pane');
    var errorBar = document.getElementById('mjml-error-bar');
    if (!editor || !preview || !errorBar) return;

    function updatePreview() {
      var mjml = editor.value;
      errorBar.textContent = '';
      preview.textContent = 'Rendering...';
      window.convertMJMLWithAPI(mjml, function(result) {
        if (result.html) {
          preview.innerHTML = result.html;
        } else {
          preview.textContent = '';
        }
        if (result.errors && result.errors.length > 0) {
          errorBar.textContent = result.errors.join('\n');
          errorBar.style.background = '#dc3545';
          errorBar.style.color = '#fff';
        } else {
          errorBar.textContent = '';
          errorBar.style.background = '';
        }
      });
    }
    editor.addEventListener('input', updatePreview);
    // Initial render
    updatePreview();
  }
  window.setupMJMLLivePreview = setupMJMLLivePreview;

  // --- Insert HTML into CKEditor Source ---
  function insertHTMLIntoCKEditor(html) {
    // Find CKEditor instance
    if (window.CKEDITOR && Object.keys(CKEDITOR.instances).length > 0) {
      var editorName = Object.keys(CKEDITOR.instances)[0];
      var editor = CKEDITOR.instances[editorName];
      // Switch to source mode if not already
      if (editor.mode !== 'source') {
        editor.setMode('source');
        setTimeout(function() {
          editor.setData(html);
        }, 300); // Wait for mode switch
      } else {
        editor.setData(html);
      }
    }
  }
  window.insertHTMLIntoCKEditor = insertHTMLIntoCKEditor;

  // --- Wire Save Button to Insert HTML ---
  function setupSaveButton() {
    var saveBtn = document.getElementById('mjml-save-btn');
    var editor = document.getElementById('mjml-code-editor');
    var errorBar = document.getElementById('mjml-error-bar');
    if (!saveBtn || !editor) return;
    saveBtn.onclick = function() {
      var mjml = editor.value;
      errorBar.textContent = 'Converting and saving...';
      window.convertMJMLWithAPI(mjml, function(result) {
        if (result.html) {
          window.insertHTMLIntoCKEditor(result.html);
          errorBar.textContent = 'HTML inserted into CKEditor.';
          errorBar.style.background = '#17a2b8';
        } else {
          errorBar.textContent = result.errors.join('\n');
          errorBar.style.background = '#dc3545';
        }
      });
    };
  }
  window.setupSaveButton = setupSaveButton;

  // --- MJML Documentation Modal ---
  const MJML_TAGS = [
    {
      tag: 'mj-section',
      desc: 'Defines a section in the email',
      props: [
        { name: 'background-color', desc: 'Section background color' },
        { name: 'padding', desc: 'Section padding' }
      ]
    },
    {
      tag: 'mj-column',
      desc: 'Defines a column within a section',
      props: [
        { name: 'width', desc: 'Column width' }
      ]
    },
    {
      tag: 'mj-text',
      desc: 'Adds text content',
      props: [
        { name: 'color', desc: 'Text color' },
        { name: 'font-size', desc: 'Font size' }
      ]
    },
    {
      tag: 'mj-image',
      desc: 'Adds an image',
      props: [
        { name: 'src', desc: 'Image URL' },
        { name: 'alt', desc: 'Alt text' }
      ]
    },
    {
      tag: 'mj-button',
      desc: 'Adds a button',
      props: [
        { name: 'href', desc: 'Button link' },
        { name: 'background-color', desc: 'Button background color' }
      ]
    },
    {
      tag: 'mj-divider',
      desc: 'Adds a horizontal divider',
      props: [
        { name: 'border-color', desc: 'Divider color' }
      ]
    }
  ];

  function showMJMLDocs() {
    if (document.getElementById('mjml-docs-modal')) return;
    var modal = document.createElement('div');
    modal.id = 'mjml-docs-modal';
    modal.innerHTML = `
      <div class="mjml-modal-backdrop"></div>
      <div class="mjml-docs-content">
        <div class="mjml-docs-header">
          <span class="mjml-docs-title">MJML Tag Reference</span>
          <button class="mjml-docs-close" title="Close">&times;</button>
        </div>
        <div class="mjml-docs-list">
          ${MJML_TAGS.map(tag => `
            <div class="mjml-doc-tag">
              <strong>&lt;${tag.tag}&gt;</strong>: ${tag.desc}
              <ul>
                ${tag.props.map(p => `<li><b>${p.name}</b>: ${p.desc}</li>`).join('')}
              </ul>
            </div>
          `).join('')}
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    modal.querySelector('.mjml-docs-close').onclick = function() { modal.remove(); };
    modal.querySelector('.mjml-modal-backdrop').onclick = function() { modal.remove(); };
  }
  window.showMJMLDocs = showMJMLDocs;

  // Wire MJML Docs button
  function setupDocsButton() {
    var docsBtn = document.getElementById('mjml-doc-btn');
    if (docsBtn) docsBtn.onclick = window.showMJMLDocs;
  }
  window.setupDocsButton = setupDocsButton;

  // --- Tag Property Helper ---
  function showTagHelper(tagName) {
    var helper = document.getElementById('mjml-tag-helper');
    if (!helper) {
      helper = document.createElement('div');
      helper.id = 'mjml-tag-helper';
      helper.style.position = 'absolute';
      helper.style.zIndex = 9999;
      helper.style.background = '#fff';
      helper.style.border = '1px solid #ced4da';
      helper.style.padding = '8px';
      helper.style.fontSize = '13px';
      helper.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
      document.body.appendChild(helper);
    }
    var tag = MJML_TAGS.find(t => t.tag === tagName);
    if (tag) {
      helper.innerHTML = `<b>&lt;${tag.tag}&gt;</b>: ${tag.desc}<ul>${tag.props.map(p => `<li><b>${p.name}</b>: ${p.desc}</li>`).join('')}</ul>`;
      helper.style.display = 'block';
    } else {
      helper.style.display = 'none';
    }
  }
  function hideTagHelper() {
    var helper = document.getElementById('mjml-tag-helper');
    if (helper) helper.style.display = 'none';
  }
  function setupTagHelper() {
    var editor = document.getElementById('mjml-code-editor');
    if (!editor) return;
    editor.addEventListener('keyup', function(e) {
      var cursor = editor.selectionStart;
      var text = editor.value.substring(0, cursor);
      var match = text.match(/<([a-zA-Z0-9\-]+)$/);
      if (match) {
        var tagName = match[1];
        var rect = editor.getBoundingClientRect();
        showTagHelper(tagName);
        var helper = document.getElementById('mjml-tag-helper');
        if (helper) {
          helper.style.left = (rect.right + 10) + 'px';
          helper.style.top = (rect.top + window.scrollY + 10) + 'px';
        }
      } else {
        hideTagHelper();
      }
    });
    editor.addEventListener('blur', hideTagHelper);
  }
  window.setupTagHelper = setupTagHelper;

  // --- Accessibility, Keyboard Navigation, and Responsive Design ---
  function enhanceAccessibilityAndResponsive() {
    var modal = document.getElementById('mjml-editor-modal');
    if (!modal) return;
    // Set ARIA roles
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', 'MJML Email Editor');
    // Focus management
    var firstInput = modal.querySelector('input, textarea, button');
    if (firstInput) firstInput.focus();
    // Trap focus inside modal
    modal.addEventListener('keydown', function(e) {
      if (e.key === 'Tab') {
        var focusable = modal.querySelectorAll('input, textarea, button, [tabindex]:not([tabindex="-1"])');
        focusable = Array.prototype.slice.call(focusable);
        var index = focusable.indexOf(document.activeElement);
        if (e.shiftKey) {
          if (index === 0) {
            focusable[focusable.length - 1].focus();
            e.preventDefault();
          }
        } else {
          if (index === focusable.length - 1) {
            focusable[0].focus();
            e.preventDefault();
          }
        }
      }
      // ESC to close
      if (e.key === 'Escape') {
        modal.remove();
      }
    });
    // Keyboard shortcuts
    modal.addEventListener('keydown', function(e) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        var saveBtn = document.getElementById('mjml-save-btn');
        if (saveBtn) saveBtn.click();
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        var docsBtn = document.getElementById('mjml-doc-btn');
        if (docsBtn) docsBtn.click();
      }
    });
    // Responsive design
    var content = modal.querySelector('.mjml-modal-content');
    if (content) {
      content.style.maxWidth = '95vw';
      content.style.width = '700px';
      content.style.height = 'auto';
      content.style.maxHeight = '90vh';
      content.style.overflow = 'auto';
    }
    // Add aria-labels to buttons
    var buttons = modal.querySelectorAll('button');
    buttons.forEach(function(btn) {
      if (!btn.getAttribute('aria-label')) {
        btn.setAttribute('aria-label', btn.textContent.trim());
      }
    });
  }
  window.enhanceAccessibilityAndResponsive = enhanceAccessibilityAndResponsive;

  // --- General Validation Logging ---
  function logFeatureStatus() {
    console.log('[MJML Extension] Validation checklist:');
    console.log('- CKEditor button injected:', !!document.querySelector('.cke_toolbar button'));
    console.log('- Modal opens:', !!document.getElementById('mjml-editor-modal'));
    console.log('- MJML CRUD API available:', typeof window.mjmlTemplateAPI === 'object');
    console.log('- MJML conversion API available:', typeof window.convertMJMLWithAPI === 'function');
    console.log('- Live preview working:', !!document.getElementById('mjml-preview-pane'));
    console.log('- Docs button present:', !!document.getElementById('mjml-doc-btn'));
    console.log('- Tag helper present:', !!document.getElementById('mjml-tag-helper'));
    console.log('- Accessibility enhanced:', document.getElementById('mjml-editor-modal')?.getAttribute('role') === 'dialog');
  }
  window.logFeatureStatus = logFeatureStatus;

  // --- Troubleshooting and Logging Enhancements ---
  function logError(message) {
    console.error('[MJML Extension]', message);
  }
  function showUserError(message) {
    var errorBar = document.getElementById('mjml-error-bar');
    if (errorBar) {
      errorBar.textContent = message;
      errorBar.style.background = '#dc3545';
      errorBar.style.color = '#fff';
    }
  }
  // Example: catch and log errors in key actions
  window.addEventListener('error', function(e) {
    logError(e.message);
    showUserError('Unexpected error: ' + e.message);
  });
  // ... existing code above (createMJMLModal, setupMJMLLivePreview, etc.) ...

  function logAcceptanceCriteria() {
    console.log('[MJML Extension] Acceptance Criteria:');
    // ... your log messages ...
  }

  // EXPOSE THE MAIN FUNCTION TO THE WINDOW
  window.createMJMLModal = function() {
    // 1. Check if modal already exists to prevent duplicates
    if (document.getElementById('mjml-editor-modal')) return;

    // 2. Call the internal function that builds the HTML
    // Note: Ensure your internal function name matches (e.g., createMJMLModalInternal)
    // or just move the building logic directly here.
    buildModalUI(); 

    // 3. Immediately run enhancements without the 'wrapping' error
    console.log('[MJML] Initializing modal enhancements...');
    setTimeout(function() {
      if (typeof window.setupMJMLLivePreview === 'function') window.setupMJMLLivePreview();
      if (typeof window.setupSaveButton === 'function') window.setupSaveButton();
      if (typeof window.setupDocsButton === 'function') window.setupDocsButton();
      if (typeof window.setupTagHelper === 'function') window.setupTagHelper();
      if (typeof window.enhanceAccessibilityAndResponsive === 'function') window.enhanceAccessibilityAndResponsive();
    }, 100);
  };

  // Helper to build the UI
  function buildModalUI() {
    var modal = document.createElement('div');
    modal.id = 'mjml-editor-modal';
    // Add modal CSS for centering and sizing
    var style = document.createElement('style');
    style.id = 'mjml-editor-modal-style';
    style.textContent = `
      #mjml-editor-modal {
        position: fixed;
        top: 0; left: 0; width: 100vw; height: 100vh;
        display: flex; align-items: center; justify-content: center;
        z-index: 99999;
      }
      #mjml-editor-modal .mjml-modal-backdrop {
        position: absolute; top: 0; left: 0; width: 100vw; height: 100vh;
        background: rgba(0,0,0,0.4);
        z-index: 0;
      }
      #mjml-editor-modal .mjml-modal-content {
        position: relative;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.25);
        width: 700px; max-width: 95vw;
        min-width: 320px;
        padding: 0;
        z-index: 1;
        display: flex;
        flex-direction: column;
        max-height: 90vh;
        overflow: hidden;
      }
      #mjml-editor-modal .mjml-modal-header {
        display: flex; align-items: center; justify-content: space-between;
        padding: 16px 20px 12px 20px;
        border-bottom: 1px solid #eee;
        background: #f8f9fa;
        border-radius: 8px 8px 0 0;
      }
      #mjml-editor-modal .mjml-modal-title {
        font-size: 1.25rem; font-weight: bold;
      }
      #mjml-editor-modal .mjml-modal-close {
        background: none; border: none; font-size: 1.5rem; cursor: pointer;
        color: #888; transition: color 0.2s;
      }
      #mjml-editor-modal .mjml-modal-close:hover {
        color: #d33;
      }
      #mjml-editor-modal .mjml-modal-body {
        display: flex; flex-direction: row; gap: 16px;
        padding: 20px;
        background: #fff;
        flex: 1 1 auto;
        min-height: 320px;
        max-height: 60vh;
        overflow: auto;
      }
      #mjml-code-editor {
        width: 48%; min-width: 180px; height: 320px; min-height: 200px;
        font-family: 'Fira Mono', 'Consolas', monospace;
        font-size: 15px;
        border: 1px solid #ced4da;
        border-radius: 4px;
        padding: 10px;
        resize: vertical;
        background: #f9f9f9;
        box-sizing: border-box;
      }
      #mjml-preview-pane {
        width: 48%; min-width: 180px; height: 320px; min-height: 200px;
        border: 1px solid #e3e3e3;
        border-radius: 4px;
        background: #fff;
        overflow: auto;
        box-sizing: border-box;
        padding: 10px;
      }
      #mjml-editor-modal .mjml-modal-actions {
        display: flex; justify-content: flex-end; align-items: center;
        padding: 14px 20px;
        border-top: 1px solid #eee;
        background: #f8f9fa;
        border-radius: 0 0 8px 8px;
      }
      #mjml-save-btn {
        background: #007bff; color: #fff; border: none; border-radius: 4px;
        padding: 8px 18px; font-size: 1rem; cursor: pointer;
        transition: background 0.2s;
      }
      #mjml-save-btn:hover {
        background: #0056b3;
      }
      #mjml-error-bar {
        margin-top: 8px; padding: 6px 10px; border-radius: 4px;
        font-size: 0.95rem; min-height: 22px;
      }
    `;
    document.head.appendChild(style);
    modal.innerHTML = `
      <div class="mjml-modal-backdrop"></div>
      <div class="mjml-modal-content">
        <div class="mjml-modal-header">
          <span class="mjml-modal-title">MJML Email Editor</span>
          <button class="mjml-modal-close" title="Close">&times;</button>
        </div>
        <div class="mjml-modal-body">
          <textarea id="mjml-code-editor" placeholder="Write your MJML here..."></textarea>
          <div id="mjml-preview-pane"></div>
        </div>
        <div class="mjml-modal-actions">
          <button id="mjml-save-btn">Save to CKEditor</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    // Close logic
    modal.querySelector('.mjml-modal-close').onclick = function() {
      modal.remove();
      var styleEl = document.getElementById('mjml-editor-modal-style');
      if (styleEl) styleEl.remove();
    };
    // Also remove style on backdrop click
    modal.querySelector('.mjml-modal-backdrop').onclick = function() {
      modal.remove();
      var styleEl = document.getElementById('mjml-editor-modal-style');
      if (styleEl) styleEl.remove();
    };
  }

})(); // End of IIFE
